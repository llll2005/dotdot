require("dropbar").setup({})
vim.ui.select = require('dropbar.utils.menu').select

