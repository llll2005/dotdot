#include<iostream>
using namespace std;
int main (){
  cout << "suceed" << endl;
}
