require('lualine').setup({
  options = {
    theme = 'auto'
  }
})
