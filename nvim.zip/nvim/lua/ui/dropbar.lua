require("dropbar").setup({
  -- dropbar_menu_t:fuzzy_find_open()
})
vim.ui.select = require('dropbar.utils.menu').select

